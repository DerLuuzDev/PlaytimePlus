package me.derluuz.playtimecommand.commands;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3468;
import net.minecraft.class_5250;

import static me.derluuz.playtimecommand.utils.FormatPlaytime.formatPlaytime;

public class TopCommand {
    private static final Logger LOGGER = LogManager.getLogger(TopCommand.class);

    private static final int PLAYERS_PER_PAGE = 10;
    private static final long CACHE_DURATION_MS = 3000; // 3 seconds
    private static final long LOADING_MESSAGE_DELAY_MS = 500;

    private static List<PlayerPlaytime> cachedPlayerList = null;
    private static long lastCacheTime = 0;

    public static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();

        // try to get page number from arguments, default to 1 if not provided
        int page = 1;
        try {
            page = IntegerArgumentType.getInteger(context, "page");
        } catch (IllegalArgumentException ignored) {
        }

        final int requestedPage = page;
        long currentTime = System.currentTimeMillis();
        if (cachedPlayerList != null && (currentTime - lastCacheTime) < CACHE_DURATION_MS) {
            class_2561 leaderboard = buildLeaderboardPage(cachedPlayerList, requestedPage);
            source.method_9226(() -> leaderboard, false);
            return 1;
        }

        AtomicBoolean calculationComplete = new AtomicBoolean(false);

        // send loading message if it has been more than a sec
        CompletableFuture.runAsync(() -> {
            try {
                Thread.sleep(LOADING_MESSAGE_DELAY_MS);
                if (!calculationComplete.get()) {
                    source.method_9226(() -> class_2561.method_43470("Calculating playtime leaderboard...")
                            .method_27692(class_124.field_1054), false);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });

        // calculate leaderboard asynchronously
        CompletableFuture.runAsync(() -> {
            try {
                List<PlayerPlaytime> playerList = calculatePlayerList(source);

                // cache result
                cachedPlayerList = playerList;
                lastCacheTime = System.currentTimeMillis();
                calculationComplete.set(true);

                // build and print result for requested page
                class_2561 leaderboard = buildLeaderboardPage(playerList, requestedPage);
                source.method_9226(() -> leaderboard, false);
            } catch (Exception e) {
                calculationComplete.set(true);
                source.method_9213(class_2561.method_43470("An error occurred while calculating the leaderboard!"));
                LOGGER.error("Error calculating leaderboard", e);
            }
        });

        return 1;
    }

    private static List<PlayerPlaytime> calculatePlayerList(class_2168 source) {
        var server = source.method_9211();
        var onlinePlayers = server.method_3760().method_14571();
        var allProfiles = me.derluuz.playtimecommand.utils.OfflinePlayerUtils.getAllProfiles(server);

        Map<UUID, PlayerPlaytime> leaderboardMap = new HashMap<>();

        // Add online players first for most accurate data
        for (class_3222 player : onlinePlayers) {
            int playtimeTicks = player.method_14248().method_15025(class_3468.field_15419.method_14956(class_3468.field_15417));
            if (playtimeTicks > 0) {
                leaderboardMap.put(player.method_5667(), new PlayerPlaytime(player.method_5820(), playtimeTicks));
            }
        }

        // Add offline players if not already present
        for (com.mojang.authlib.GameProfile profile : allProfiles) {
            UUID id = me.derluuz.playtimecommand.utils.OfflinePlayerUtils.getProfileId(profile);
            if (id != null && !leaderboardMap.containsKey(id)) {
                int playtime = me.derluuz.playtimecommand.utils.OfflinePlayerUtils.getOfflinePlaytime(server, id);
                if (playtime > 0) {
                    leaderboardMap.put(id, new PlayerPlaytime(
                            me.derluuz.playtimecommand.utils.OfflinePlayerUtils.getProfileName(profile), playtime));
                }
            }
        }

        return leaderboardMap.values().stream()
                .sorted(Comparator.comparingInt(PlayerPlaytime::playtimeTicks).reversed())
                .toList();
    }

    private static class_2561 buildLeaderboardPage(List<PlayerPlaytime> playerList, int page) {
        int totalPlayers = playerList.size();
        int totalPages = (int) Math.ceil((double) totalPlayers / PLAYERS_PER_PAGE);

        // validate page number
        if (page < 1) {
            page = 1;
        }
        if (page > totalPages && totalPages > 0) {
            page = totalPages;
        }

        final int finalPage = page;

        int startIndex = (finalPage - 1) * PLAYERS_PER_PAGE;
        int endIndex = Math.min(startIndex + PLAYERS_PER_PAGE, totalPlayers);

        // build the leaderboard message
        // header
        class_5250 leaderboard = class_2561.method_43470("━━━━━━ ")
                .method_27692(class_124.field_1065)
                .method_10852(class_2561.method_43470("Playtime Leaderboard")
                        .method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470(" ━━━━━━\n")
                        .method_27692(class_124.field_1065));

        for (int i = startIndex; i < endIndex; i++) {
            PlayerPlaytime pp = playerList.get(i);
            int position = i + 1;
            String formattedTime = formatPlaytime(pp.playtimeTicks());

            // remove period from playtime since its cleaner
            if (formattedTime.endsWith(".")) {
                formattedTime = formattedTime.substring(0, formattedTime.length() - 1);
            }

            leaderboard = leaderboard
                    .method_10852(class_2561.method_43470(position + ". ")
                            .method_27692(class_124.field_1065))
                    .method_10852(class_2561.method_43470(pp.playerName())
                            .method_27692(class_124.field_1060))
                    .method_10852(class_2561.method_43470(" - ")
                            .method_27692(class_124.field_1063))
                    .method_10852(class_2561.method_43470(formattedTime)
                            .method_27692(class_124.field_1054));

            if (i < endIndex - 1) {
                leaderboard = leaderboard.method_10852(class_2561.method_43470("\n"));
            }
        }

        // page navigation (if there are multiple pages)
        if (totalPages > 1) {
            leaderboard = leaderboard.method_10852(class_2561.method_43470("\n"));

            class_5250 navigation = class_2561.method_43470("━━━━")
                    .method_27692(class_124.field_1065);

            // add buttons
            // previous page button
            if (finalPage > 1) {
                net.minecraft.class_2583 prevStyle = net.minecraft.class_2583.field_24360
                        .method_10977(class_124.field_1075)
                /*
                 * .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND,
                 * "/playtime --top " + (finalPage - 1)))
                 * .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                 * Component.literal("Go to page " + (finalPage -
                 * 1)).withStyle(ChatFormatting.GREEN)))
                 */
                ;
                navigation = navigation.method_10852(class_2561.method_43470(" << Prev").method_10862(prevStyle));
            } else {
                navigation = navigation.method_10852(class_2561.method_43470(" << Prev").method_27692(class_124.field_1063));
            }

            navigation = navigation
                    .method_10852(class_2561.method_43470(" " + finalPage + "/" + totalPages + " ").method_27692(class_124.field_1080));

            // next page button
            if (finalPage < totalPages) {
                net.minecraft.class_2583 nextStyle = net.minecraft.class_2583.field_24360
                        .method_10977(class_124.field_1075)
                /*
                 * .withClickEvent(
                 * new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/playtime --top " + (finalPage
                 * + 1)))
                 * .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                 * Component.literal("Go to page " + (finalPage +
                 * 1)).withStyle(ChatFormatting.GREEN)))
                 */
                ;
                navigation = navigation.method_10852(class_2561.method_43470("Next >> ").method_10862(nextStyle));
            } else {
                navigation = navigation.method_10852(class_2561.method_43470("Next >> ").method_27692(class_124.field_1063));
            }

            navigation = navigation.method_10852(class_2561.method_43470("━━━━").method_27692(class_124.field_1065));

            leaderboard = leaderboard.method_10852(navigation);
        }

        return leaderboard;
    }

    private record PlayerPlaytime(String playerName, int playtimeTicks) {
    }
}
