package me.derluuz.playtimecommand.commands;

import com.mojang.brigadier.context.CommandContext;
import me.derluuz.playtimecommand.PlaytimeCommand;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;

public class AboutCommand {

    public static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();

        class_2561 aboutMessage = class_2561.method_43473()
                .method_10852(class_2561.method_43470("Playtime Command")
                        .method_27695(class_124.field_1065, class_124.field_1067))
                .method_10852(class_2561.method_43470(" " + PlaytimeCommand.getCurrentVersion())
                        .method_27695(class_124.field_1065, class_124.field_1067))
                .method_10852(class_2561.method_43470(" by ")
                        .method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470("DerLuuz")
                        .method_27692(class_124.field_1077));

        source.method_9226(() -> aboutMessage, false);
        return 1;
    }
}
