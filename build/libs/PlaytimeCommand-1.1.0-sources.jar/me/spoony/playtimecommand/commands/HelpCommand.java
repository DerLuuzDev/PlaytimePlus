package me.spoony.playtimecommand.commands;

import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;

public class HelpCommand {

    public static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();

        class_2561 helpMessage = class_2561.method_43470("Playtime Command Help\n")
                .method_27692(class_124.field_1065)
                .method_10852(class_2561.method_43470("/playtime - See your own playtime\n"))
                .method_10852(class_2561.method_43470("/playtime ").method_10852(class_2561.method_43470("<username>").method_27692(class_124.field_1077)).method_10852(class_2561.method_43470(" - See another online player's playtime\n")))
                .method_10852(class_2561.method_43470("/playtime ").method_10852(class_2561.method_43470("--top").method_27692(class_124.field_1077)).method_10852(class_2561.method_43470(" - See top 10 players by playtime\n")))
                .method_10852(class_2561.method_43470("/playtime ").method_10852(class_2561.method_43470("--about").method_27692(class_124.field_1077)).method_10852(class_2561.method_43470(" - See mod information\n")))
                .method_10852(class_2561.method_43470("/playtime ").method_10852(class_2561.method_43470("--help").method_27692(class_124.field_1077)).method_10852(class_2561.method_43470(" - See command usage")));

        source.method_9226(() -> helpMessage, false);
        return 1;
    }
}