package me.spoony.playtimecommand.commands;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import me.spoony.playtimecommand.utils.OfflinePlayerUtils;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.server.MinecraftServer;

public class RemoveCommand {

    public static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        String playerName = StringArgumentType.getString(context, "player");
        MinecraftServer server = source.method_9211();

        // Check permission (OP Level 2+)
        if (source.method_43737()) {
            boolean hasPerm = false;
            try {
                // Direct check via reflection helper
                if (OfflinePlayerUtils.isOp(server, source.method_9207().method_7334())) {
                    hasPerm = true;
                }
            } catch (Exception e) {
            }
            if (!hasPerm) {
                source.method_9213(class_2561.method_43470("You do not have permission to remove player stats."));
                return 0;
            }
        } else {
            // Console always has permission
        }

        // Try to find the profile
        var profileOpt = OfflinePlayerUtils.getProfileByName(server, playerName);

        if (profileOpt.isEmpty()) {
            source.method_9213(class_2561.method_43470("Player '" + playerName + "' not found in cache."));
            return 0;
        }

        GameProfile profile = profileOpt.get();
        java.util.UUID uuid = OfflinePlayerUtils.getProfileId(profile);

        if (uuid == null) {
            source.method_9213(class_2561.method_43470("Could not resolve UUID for player '" + playerName + "'."));
            return 0;
        }

        // Delete the stats file
        boolean deleted = OfflinePlayerUtils.deletePlayerStats(server, uuid);

        if (deleted) {
            source.method_9226(() -> class_2561.method_43470("Successfully removed stats for ")
                    .method_27692(class_124.field_1060)
                    .method_10852(class_2561.method_43470(playerName).method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470(". They will no longer appear in the leaderboard or suggestions.")
                            .method_27692(class_124.field_1060)),
                    true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to delete stats file for '" + playerName
                    + "'. It might not exist or the server couldn't access it."));
            return 0;
        }
    }
}
