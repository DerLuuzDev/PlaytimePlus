package me.spoony.playtimecommand.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import java.util.Optional;
import com.mojang.authlib.GameProfile;
import me.spoony.playtimecommand.utils.OfflinePlayerUtils;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3468;

import static me.spoony.playtimecommand.utils.FormatPlaytime.formatPlaytime;

public class RootCommand {

    // Suggest all known players (online + offline cache)
    private static final SuggestionProvider<class_2168> ALL_PLAYERS = (context, builder) -> {
        return class_2172.method_9265(
                OfflinePlayerUtils.getAllOfflinePlayerNames(context.getSource().method_9211()),
                builder);
    };

    public static void register(CommandDispatcher<class_2168> dispatcher,
            net.minecraft.class_7157 registryAccess,
            class_2170.class_5364 environment) {
        dispatcher.register(class_2170.method_9247("playtime")
                .executes(RootCommand::execute)
                .then(class_2170.method_9244("player", StringArgumentType.word())
                        .suggests(ALL_PLAYERS)
                        .executes(RootCommand::executeOtherPlayer))
                .then(class_2170.method_9247("--top")
                        .executes(TopCommand::execute)
                        .then(class_2170.method_9244("page", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1))
                                .executes(TopCommand::execute)))
                .then(class_2170.method_9247("remove")
                        // Permission check moved to execute method for safety
                        .then(class_2170.method_9244("player", StringArgumentType.word())
                                .suggests(ALL_PLAYERS)
                                .executes(RemoveCommand::execute)))
                .then(class_2170.method_9247("--about")
                        .executes(AboutCommand::execute))
                .then(class_2170.method_9247("--help")
                        .executes(HelpCommand::execute)));
    }

    private static int execute(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();

        // ask for username if console
        if (!source.method_43737()) {
            source.method_9213(class_2561.method_43470("Please specify a player: /playtime <player>"));
            return 0;
        }

        try {
            class_3222 player = source.method_9207();
            return printPlaytime(player.method_5820(),
                    player.method_14248().method_15025(class_3468.field_15419.method_14956(class_3468.field_15417)), source, true);
        } catch (Exception e) {
            source.method_9213(class_2561.method_43470("An error occurred while executing the command!"));
            return 0;
        }
    }

    private static int executeOtherPlayer(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();

        try {
            String playerName = StringArgumentType.getString(context, "player");
            class_3222 targetPlayer = source.method_9211().method_3760().method_14566(playerName);

            if (targetPlayer != null) {
                // Player is online
                int playtime = targetPlayer.method_14248().method_15025(class_3468.field_15419.method_14956(class_3468.field_15417));
                return printPlaytime(targetPlayer.method_5820(), playtime, source,
                        source.method_43737() && source.method_44023() == targetPlayer);
            } else {
                // Player is offline, try to find in cache
                Optional<GameProfile> profileOptional = OfflinePlayerUtils.getProfileByName(source.method_9211(),
                        playerName);

                if (profileOptional.isPresent()) {
                    GameProfile profile = profileOptional.get();
                    int playtime = OfflinePlayerUtils.getOfflinePlaytime(source.method_9211(),
                            OfflinePlayerUtils.getProfileId(profile));

                    if (playtime == 0) {
                        // Could mean actual 0 or file not found.
                        // We'll treat it as valid but maybe warn if it seems suspicious?
                        // For now, just print it.
                    }

                    return printPlaytime(OfflinePlayerUtils.getProfileName(profile), playtime, source, false);
                } else {
                    source.method_9213(
                            class_2561.method_43470("Player '" + playerName + "' not found (never joined or not in cache)!"));
                    return 0;
                }
            }
        } catch (Exception e) {
            source.method_9213(class_2561.method_43470("An error occurred while executing the command!"));
            e.printStackTrace(); // Log error for debugging
            return 0;
        }
    }

    private static int printPlaytime(String playerName, int playtimeTicks, class_2168 source, boolean isSelf) {
        String formattedTime = formatPlaytime(playtimeTicks);

        class_2561 message = class_2561.method_43473()
                .method_10852(class_2561.method_43470(isSelf ? "Your playtime is " : playerName + "'s playtime is ")
                        .method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470(formattedTime).method_27695(class_124.field_1065, class_124.field_1067));

        source.method_9226(() -> message, false);
        return 1;
    }
}